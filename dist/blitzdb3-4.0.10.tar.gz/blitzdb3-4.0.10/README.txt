### Blitzdb ported to newer Python3 with some minor changes (see diff)

Orignal source/license info and acknowelegement(s) at https://github.com/adewes/blitzdb and https://github.com/abilian/blitzdb3
